package model;

public class Instructor {
    private int user_id;
    private String department;

    public int getUser_id() { return user_id;}
    public void setUser_id(int user_id) {this.user_id = user_id;}

    public String getDepartment() { return department;}
    public void setDepartment(String department) {this.department = department;}
}
